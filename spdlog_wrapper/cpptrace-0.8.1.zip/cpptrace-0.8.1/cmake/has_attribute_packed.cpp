struct __attribute__((packed)) foo {
    int i;
    double d;
};

int main() {}
